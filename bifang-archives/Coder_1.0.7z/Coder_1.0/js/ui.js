// all UI modules that must be loaded independently

define([
  "ui/cli",
  "ui/keys",
  "ui/menus",
  "ui/palette",
  "ui/projectManager",
  "ui/searchbar",
  "ui/window"
]);