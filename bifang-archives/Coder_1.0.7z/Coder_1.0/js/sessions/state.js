define({
  tabs: [],
  stack: []
});